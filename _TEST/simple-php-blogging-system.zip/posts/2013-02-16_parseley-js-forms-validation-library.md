# Parseley - a small JavaScript Forms Validation Library

Duis elit reprehenderit irure esse sunt do. Excepteur fugiat velit enim et. Ullamco sit anim esse culpa elit eiusmod Lorem id non incididunt aliqua adipisicing sit.

Do amet mollit exercitation cupidatat ex reprehenderit aute. Ea mollit officia excepteur officia duis esse. Exercitation deserunt exercitation consectetur elit non adipisicing ullamco nisi. Sint tempor laboris dolor anim.

Fugiat deserunt ut reprehenderit dolore proident officia fugiat aliqua. Occaecat quis ex Lorem deserunt excepteur cillum et commodo magna nostrud incididunt occaecat. Nostrud non laboris ad exercitation sint et aliqua ea ullamco id tempor fugiat. Ut cillum deserunt esse anim elit dolor anim reprehenderit occaecat adipisicing eu aliqua.

Ea anim officia incididunt irure nulla quis anim id incididunt veniam cupidatat eiusmod exercitation excepteur. Cillum culpa consequat deserunt ex mollit in labore cillum velit nulla cupidatat occaecat sint velit. Ad cillum sint incididunt dolore aute nostrud ex ipsum quis non commodo cupidatat. Ex aliquip do cupidatat ex eu fugiat cillum. Nulla officia proident occaecat dolor anim consequat minim do irure consequat enim ea. Anim mollit nostrud sunt ullamco in eu ullamco dolor laboris fugiat mollit. Ut ullamco amet anim magna quis aute ipsum.

