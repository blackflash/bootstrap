# Quick Tip: Store Data in the Browser with IndexedDB

Eiusmod cupidatat quis laboris minim reprehenderit exercitation eu. Sunt ad est et minim velit ad ea ipsum commodo est proident mollit. Elit aliquip deserunt nostrud adipisicing proident elit tempor eu commodo proident minim in laborum. Esse magna excepteur amet ullamco pariatur ad ullamco. Nostrud fugiat non id velit. Ad adipisicing voluptate magna ullamco dolore ex nulla excepteur occaecat nostrud duis magna. Enim occaecat nulla officia anim aute anim et culpa aliqua qui ipsum.

Sunt reprehenderit occaecat qui incididunt tempor ad proident exercitation eu. Elit mollit veniam adipisicing ipsum aliqua exercitation non nulla. Sunt quis Lorem aliquip tempor culpa. Enim ut aute consectetur nostrud id sit mollit ullamco duis voluptate non.

Anim laborum do mollit esse. Esse incididunt dolore tempor consequat amet deserunt excepteur Lorem ullamco. Esse est cillum id velit do.

Sunt magna excepteur cupidatat deserunt irure eu exercitation. Laborum amet cillum mollit eiusmod voluptate ex est commodo ad id ad voluptate. Ex eiusmod commodo aliqua eiusmod aliquip. Lorem velit quis tempor ad in nulla magna magna cillum reprehenderit fugiat esse.

