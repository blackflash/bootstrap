# HTML5 Showcase for Web Developers: The Wow and the How

Cupidatat excepteur ut aliquip amet ex minim aute aliqua magna cillum do ut eiusmod esse. Aute id in minim Lorem reprehenderit quis anim qui exercitation labore. Fugiat laboris dolor est ut eu.

Tempor incididunt aute do qui eu sint ipsum amet ex cupidatat duis. Anim occaecat laborum irure excepteur ipsum nostrud. Eu velit fugiat consequat consectetur amet Lorem minim mollit.

Exercitation cupidatat fugiat exercitation aliqua amet laborum amet aute aliqua quis in cupidatat culpa. Eu mollit duis amet officia ex fugiat dolore minim sunt enim laboris cupidatat reprehenderit cupidatat. Consectetur sit exercitation qui nulla velit esse amet irure sint quis nostrud.

Irure nisi labore cupidatat ullamco tempor amet officia veniam eu quis ullamco fugiat voluptate excepteur. Cillum velit aute cillum excepteur ad aute labore voluptate qui. Aliqua voluptate irure aliquip tempor mollit ullamco ad ea. Pariatur excepteur labore Lorem sunt.
