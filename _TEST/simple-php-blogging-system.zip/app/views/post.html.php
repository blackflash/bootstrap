<div class="post">

	<h2><?php echo $p->title ?></h2>

	<div class="date"><?php echo date('d F Y', $p->date)?></div>

	<?php echo $p->body?>

</div>

