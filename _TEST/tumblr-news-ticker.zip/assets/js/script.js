$(function() {
	
	// Call the plugin
	
	$('#main').tumblrNewsTicker({
		time: 5000,
		title:  'Tumblr News Ticker',
		blog: 'http://tzinenewsdemo.tumblr.com/'
	});	
				
});